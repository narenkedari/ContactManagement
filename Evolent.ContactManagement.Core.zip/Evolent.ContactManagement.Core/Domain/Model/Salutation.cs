﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Evolent.ContactManagement.Core.Domain.Model
{
    [Serializable]
    public enum Salutation
    {
        [Description("Mr.")]
        Mr,
        [Description("Mrs.")]
        Mrs,
        [Description("Ms.")]
        Ms,
        [Description("Dr.")]
        Dr,
        [Description("Prof.")]
        Prof
    }
}