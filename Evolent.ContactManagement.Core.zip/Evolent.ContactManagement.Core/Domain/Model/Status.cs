﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Evolent.ContactManagement.Core.Domain.Model
{
    public enum Status
    {
        [Description("Active")]
        Active,
        [Description("Inactive")]
        Inactiv,
    }
}