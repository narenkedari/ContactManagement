﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Evolent.ContactManagement.Infrastructure.Persistence.Entity;
using Evolent.ContactManagement.Infrastructure.Persistence.Repositories;
using Evolent.ContactManagement.Core.Domain.Model;

namespace Evolent.ContactManagement.ContactService.Controllers
{
    public class ContactsController: ApiController
    {
        private ContactsDBEntities dbContext = new ContactsDBEntities();

        [HttpGet]
        [Route("api/contacts/GetContactList")]
        public IHttpActionResult GetContactList()
        {
            var repository = new ContactRepository(this.dbContext);
            var contactList = repository.Get();
            if (!contactList.Any())
            {
                return this.NotFound();
            }
            var contacts = this.ToDomainModel(contactList.Where(x=>x.Status.ToLower()=="active"));
            return this.Ok(contacts);
        }

        [HttpGet]
        [Route("api/contacts/GetById/{id}")]
        public IHttpActionResult GetContactById(decimal id)
        {
            ContactRepository repository = new ContactRepository(this.dbContext);
            var contactList = repository.GetByID(id);
            if (contactList==null)
            {
                return this.NotFound();
            }
            var contact = this.ToDomainModel(contactList);
            return this.Ok(contact);
        }

        [HttpPost]
        public IHttpActionResult CreateContact(ContactDetails contactDetails)
        {
            ContactRepository repository = new ContactRepository(this.dbContext);
            Contact contact = this.ToEntity(contactDetails);
            repository.Insert(contact);
            return this.Ok();
        }

        [HttpPut]
        public IHttpActionResult UpdateContact(ContactDetails contactDetails)
        {
            ContactRepository repository = new ContactRepository(this.dbContext);
            Contact contact = repository.GetByID(contactDetails.ID);
            this.UpdateDetails(contact,contactDetails);
            contact.DateModified = DateTime.Now;
            repository.Update(contact);
            return this.Ok();
        }

        [HttpDelete]
         [Route("api/contacts/DeleteContact/{id}")]
        public IHttpActionResult DeleteContact(decimal id)
        {
            ContactRepository repository = new ContactRepository(this.dbContext);
            Contact contact = repository.GetByID(id);
            contact.Status = "Inactive";
            contact.DateModified = DateTime.Now;
            repository.Update(contact);
            return this.Ok();
        }


        private List<ContactDetails> ToDomainModel(IEnumerable<Contact> contacts)
        {
           return contacts.Select(x => new ContactDetails(){FirstName = x.FirstName,LastName = x.LastName,
               Salutation = this.MapSalutation(x.Salutation),Email = x.Email, Phone = x.Phone, ID = x.ContactID, Status = this.MapStatus(x.Status)}).ToList();
        }

        private ContactDetails ToDomainModel(Contact contact)
        {
            return new ContactDetails(){FirstName = contact.FirstName,LastName = contact.LastName,
                Salutation = this.MapSalutation(contact.Salutation),Email = contact.Email, 
                Phone = contact.Phone, ID = contact.ContactID, Status = this.MapStatus(contact.Status)};
        }

        private Salutation MapSalutation(string salutation)
        {
            switch (salutation)
            {
                    case "Mr":
                    return  Salutation.Mr;
                case "Ms":
                    return  Salutation.Ms;
                case "Mrs":
                    return  Salutation.Mrs;
                case "Dr":
                    return  Salutation.Dr;
                    default:
                        return  Salutation.Prof;
            }
        }

        private Status MapStatus(string status)
        {
            switch (status.ToLower())
            {
                case "active":
                    return  Status.Active;
                default:
                    return  Status.Inactiv;
            }
        }
        private Contact ToEntity(ContactDetails details)
        {
            return new Contact()
            {
                Salutation = details.Salutation.ToString(), FirstName = details.FirstName, LastName = details.LastName,
                Email = details.Email, Phone = details.Phone, Status = "Active",DateAdded = DateTime.Now
            };
        }

        private void UpdateDetails(Contact contact, ContactDetails contactDetailsToBeUpdated)
        {
            contact.Salutation = contactDetailsToBeUpdated.Salutation.ToString();
            //contact.FirstName = contactDetailsToBeUpdated.FirstName;
            //contact.LastName = contactDetailsToBeUpdated.LastName;
            contact.Email = contactDetailsToBeUpdated.Email;
            contact.Phone = contactDetailsToBeUpdated.Phone;
        }
    }


    
}