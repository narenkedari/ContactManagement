﻿using System.Web;
using System.Web.Mvc;

namespace Evolent.ContactManagement.PublicPortal
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
