﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using Evolent.ContactManagement.Core.Domain.Model;

namespace Evolent.ContactManagement.PublicPortal.Models
{
    public class ContactDetailsViewModel
    {
        public int ID { get; set; }
        public Salutation Salutation { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public Status Status { get; set; }
    }

   
}