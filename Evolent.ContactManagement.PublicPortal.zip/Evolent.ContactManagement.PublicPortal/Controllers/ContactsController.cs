﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Evolent.ContactManagement.Infrastructure.Persistence.Entity;
using Evolent.ContactManagement.Core.Domain.Interfaces;
using Evolent.ContactManagement.Core.Domain.Model;
using Evolent.ContactManagement.PublicPortal.Models;
using Newtonsoft.Json;

namespace Evolent.ContactManagement.PublicPortal.Controllers
{
    public class ContactsController : Controller
    {
        private ContactsDBEntities dbContext = new ContactsDBEntities();

        // GET: Contacts
        public async Task<ActionResult> Index()
        {
            IEnumerable<ContactDetails> contacts = null;
            List<ContactDetailsViewModel> viewModel = null;

            using (var client = new HttpClient())
            {
                string webapiBaseUrl = ConfigurationManager.AppSettings["ContactsWebApiServiceBaseAddress"];
                client.BaseAddress = new Uri(webapiBaseUrl);
                
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("api/contacts/GetContactList");
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var contactResponse = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    contacts = JsonConvert.DeserializeObject<List<ContactDetails>>(contactResponse);
                    viewModel = this.ToViewModel(contacts);
                }

            }
            return View(viewModel);
        }

        private List<ContactDetailsViewModel> ToViewModel(IEnumerable<ContactDetails> contacts)
        {
            return contacts.Select(x => new ContactDetailsViewModel(){ID =Convert.ToInt32(x.ID), FirstName = x.FirstName,LastName = x.LastName,
                Salutation = x.Salutation, Email = x.Email, Phone = x.Phone, Status = x.Status}).ToList();
        }

        private ContactDetailsViewModel ToViewModel(ContactDetails contact)
        {
            return  new ContactDetailsViewModel(){ID =Convert.ToInt32(contact.ID), FirstName = contact.FirstName,LastName = contact.LastName,
                Salutation = contact.Salutation, Email = contact.Email, Phone = contact.Phone, Status = contact.Status};
        }
        

        // GET: Contacts/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Contacts/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(ContactDetailsViewModel contact)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    string webapiBaseUrl = ConfigurationManager.AppSettings["ContactsWebApiServiceBaseAddress"];
                    client.BaseAddress = new Uri(webapiBaseUrl);
                
                    client.DefaultRequestHeaders.Clear();
                    //Define request data format
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    
                    var json = JsonConvert.SerializeObject(contact);
                    var data = new StringContent(json, Encoding.UTF8, "application/json");
                    var response = await client.PostAsync("api/contacts/CreateContact", data);
                    
                    //Checking the response is successful or not which is sent using HttpClient
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }

                }
            }

            return View(contact);
        }

        // GET: Contacts/Edit/5
        public async Task<ActionResult> Edit(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactDetails contact = null;
            ContactDetailsViewModel viewModel = null;

            using (var client = new HttpClient())
            {
                string webapiBaseUrl = ConfigurationManager.AppSettings["ContactsWebApiServiceBaseAddress"];
                client.BaseAddress = new Uri(webapiBaseUrl);
                
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync($"api/contacts/GetById/{id}" );
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var contactResponse = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    contact = JsonConvert.DeserializeObject<ContactDetails>(contactResponse);
                    viewModel = this.ToViewModel(contact);
                }

            }
           
            if (viewModel == null)
            {
                return HttpNotFound();
            }
            return View(viewModel);
        }

        // POST: Contacts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(ContactDetailsViewModel contact)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    string webapiBaseUrl = ConfigurationManager.AppSettings["ContactsWebApiServiceBaseAddress"];
                    client.BaseAddress = new Uri(webapiBaseUrl);
                
                    client.DefaultRequestHeaders.Clear();
                    //Define request data format
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    
                    var json = JsonConvert.SerializeObject(contact);
                    var data = new StringContent(json, Encoding.UTF8, "application/json");
                    var response = await client.PutAsync("api/contacts/UpdateContact", data);
                    
                    //Checking the response is successful or not which is sent using HttpClient
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }

                }
            }
            return View(contact);
        }


       

        // GET: Contacts/Delete/5
        public async Task<ActionResult> Delete(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContactDetails contact = null;
            ContactDetailsViewModel viewModel = null;

            using (var client = new HttpClient())
            {
                string webapiBaseUrl = ConfigurationManager.AppSettings["ContactsWebApiServiceBaseAddress"];
                client.BaseAddress = new Uri(webapiBaseUrl);
                
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync($"api/contacts/GetById/{id}" );
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var contactResponse = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the Employee list
                    contact = JsonConvert.DeserializeObject<ContactDetails>(contactResponse);
                    viewModel = this.ToViewModel(contact);
                }

            }
           
            if (viewModel == null)
            {
                return HttpNotFound();
            }
            return View(viewModel);
        }

        // POST: Contacts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(ContactDetailsViewModel contact)
        {
            if (contact == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            using (var client = new HttpClient())
            {
                string webapiBaseUrl = ConfigurationManager.AppSettings["ContactsWebApiServiceBaseAddress"];
                client.BaseAddress = new Uri(webapiBaseUrl);
                
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.DeleteAsync($"api/contacts/DeleteContact/{contact.ID}" );
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
               
            }
           
            if (contact == null)
            {
                return HttpNotFound();
            }
            return this.View(contact);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dbContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
