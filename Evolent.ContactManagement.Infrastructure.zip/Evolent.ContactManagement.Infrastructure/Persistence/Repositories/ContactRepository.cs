﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evolent.ContactManagement.Core.Domain.Interfaces;
using Evolent.ContactManagement.Infrastructure.Persistence.Entity;

namespace Evolent.ContactManagement.Infrastructure.Persistence.Repositories
{
    public class ContactRepository : BaseRepository<Contact>
    {
        public ContactRepository(DbContext context) : base(context)
        {
        }
    }
}
